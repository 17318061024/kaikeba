import {LOGIN_SUCCESS, LOGOUT_SUCCESS} from '@/store/const';

export const login = () => ({type: LOGIN_SUCCESS});
export const logout = () => ({type: LOGOUT_SUCCESS});
