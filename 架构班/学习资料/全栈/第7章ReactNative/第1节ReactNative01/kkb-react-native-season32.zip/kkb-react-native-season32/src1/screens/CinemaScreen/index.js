import React, {useState, useEffect} from 'react';
import {View, Text, Button} from 'react-native';
import Section from '@/components/Section';

export default function CinemaScreen() {
  return (
    <View>
      <Section title="CinemaScreen" />
    </View>
  );
}
