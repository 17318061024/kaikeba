import React, {useState, useEffect} from 'react';
import {View, Text, Button} from 'react-native';
import Section from '@/components/Section';

export default function MovieScreen({navigation, route}) {
  return (
    <View>
      <Section title="MovieScreen" />
    </View>
  );
}
