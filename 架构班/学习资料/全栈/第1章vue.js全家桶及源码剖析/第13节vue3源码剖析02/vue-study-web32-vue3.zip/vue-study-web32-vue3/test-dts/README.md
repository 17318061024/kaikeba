# Test-ts

Tests Typescript types to ensure the types remain as expected.

## Configuration

### tsconfig.json

Config used to test against the package source

### tsconfig.build.json

Replaces the `vue` and `@vue/*` dependencies with the built Typescript to ensure the published types are correct.
