module.exports = {
    db: {
        dialect: 'mysql',
        host: 'localhost',
        database: 'kaikeba',
        username: 'root',
        password: 'example'
    },
    middleware: ['logger']
}