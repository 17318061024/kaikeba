/// <reference path="globals/react-dom/index.d.ts" />
/// <reference path="globals/react/index.d.ts" />
/// <reference path="globals/socket.io-client/index.d.ts" />
