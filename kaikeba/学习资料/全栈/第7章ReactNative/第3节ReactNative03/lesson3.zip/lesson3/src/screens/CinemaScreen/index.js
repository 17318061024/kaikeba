import React from 'react';
import {View, Text} from 'react-native';
import Section from '@/components/Section';

export default function CinemaScreen() {
  return (
    <View>
      <Section>CinemaScreen</Section>
    </View>
  );
}
