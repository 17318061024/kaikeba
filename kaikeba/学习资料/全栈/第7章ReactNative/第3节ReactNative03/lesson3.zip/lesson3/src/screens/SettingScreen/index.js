import React from 'react';
import {View, Text} from 'react-native';
import Section from '@/components/Section';

// export default function SettingScreen({navigation}) {
export default function SettingScreen() {
  return (
    <View>
      <Section>SettingScreen</Section>
    </View>
  );
}
