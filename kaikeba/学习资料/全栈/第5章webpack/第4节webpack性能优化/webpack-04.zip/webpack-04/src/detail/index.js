console.log("hello detail");
