import { renderWithHooks } from "./hooks";
import { reconcileChildren } from "./ReactChildFiber";
import { updateNode } from "./utils";

export function updateHostComponent(wip) {
  if (!wip.stateNode) {
    wip.stateNode = document.createElement(wip.type);
    updateNode(wip.stateNode, {}, wip.props);
  }

  reconcileChildren(wip, wip.props.children);
}
export function updateFunctionComponent(wip) {
  renderWithHooks(wip);
  const children = wip.type(wip.props);
  reconcileChildren(wip, children);
}

export function updateFragmentComponent(wip) {
  reconcileChildren(wip, wip.props.children);
}
