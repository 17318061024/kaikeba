import { scheduleUpdateOnFiber } from "./ReactFiberWorkloop";
import { areHookInputsEqual, HookLayout, HookPassive } from "./utils";

// new 1 2 3 4
// old 1 2 3 4

let currentlyRenderingFiber = null;
let workInProgressHook = null;
// 和workInProgressHook对应位置的老hook
let currentHook = null;

export function renderWithHooks(wip) {
  currentlyRenderingFiber = wip;
  currentlyRenderingFiber.memorizedState = null;
  workInProgressHook = null;
  currentlyRenderingFiber.updateQueueOfEffect = [];
  currentlyRenderingFiber.updateQueueOfLayout = [];
}

function updateWorkInProgressHook() {
  let hook;
  let current = currentlyRenderingFiber.alternate;
  if (current) {
    // 更新阶段
    currentlyRenderingFiber.memorizedState = current.memorizedState;

    if (workInProgressHook) {
      hook = workInProgressHook = workInProgressHook.next;
      currentHook = currentHook.next;
    } else {
      // head hook
      hook = workInProgressHook = current.memorizedState;
      currentHook = current.memorizedState;
    }
  } else {
    //   初次渲染
    currentHook = null;
    hook = {
      memorizedState: null, // 状态值
      next: null, // 下一个hook
    };
    if (workInProgressHook) {
      workInProgressHook = workInProgressHook.next = hook;
    } else {
      // head hook
      workInProgressHook = currentlyRenderingFiber.memorizedState = hook;
    }
  }
  return hook;
}

// hook = {
//     memorizedState: null// 状态值
//     next: null// 下一个hook
// }
export function useReducer(reducer, initalState) {
  const hook = updateWorkInProgressHook();
  if (!currentlyRenderingFiber.alternate) {
    //   初次渲染
    hook.memorizedState = initalState;
  }
  const dispatch = () => {
    hook.memorizedState = reducer(hook.memorizedState);
    scheduleUpdateOnFiber(currentlyRenderingFiber);
  };
  return [hook.memorizedState, dispatch];
}

export function useLayoutEffect(create, deps) {
  return updateEffectIml(HookLayout, create, deps);
}

export function useEffect(create, deps) {
  return updateEffectIml(HookPassive, create, deps);
}

function updateEffectIml(hookFlags, create, deps) {
  const hook = updateWorkInProgressHook();

  // 更新阶段，检查新旧hook上的deps是否发生变化
  if (currentHook) {
    const prevEffect = currentHook.memorizedState;
    if (deps) {
      const prevDeps = prevEffect.deps;
      if (areHookInputsEqual(deps, prevDeps)) {
        return;
      }
    }
  }
  const effect = { hookFlags, create, deps };
  hook.memorizedState = effect;
  if (hookFlags & HookPassive) {
    currentlyRenderingFiber.updateQueueOfEffect.push(effect);
  } else if (hookFlags & HookLayout) {
    currentlyRenderingFiber.updateQueueOfLayout.push(effect);
  }
}
