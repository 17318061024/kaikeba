// import React, { useState, useReducer, useEffect, useLayoutEffect } from "react";
// import ReactDOM from "react-dom";
import { useReducer, useEffect, useLayoutEffect } from "./kreact/react";
import ReactDOM from "./kreact/react-dom";
import "./index.css";

// fiber.memeorizedState(hook0)->next(hook1)->next(hook2)->next(hook3)(workInProgressHook)
// workInProgressHook
function FunctionComponent(props) {
  // const [count, setCount] = useState(0); //hook0
  const [count2, setCount2] = useReducer((x) => x + 1, 0); // hook1
  // const [count3, setCount3] = useReducer((x) => x + 1, 0); //hook2

  // useEffect(() => {
  //   console.log("omg useEffect", count2); //sy-log
  // }, [count2]);

  // useLayoutEffect(() => {
  //   console.log("omg useLayoutEffect", count2); //sy-log
  // }, []);

  return (
    <div className="border">
      <p>{props.name}</p>
      {/* <p>{count}</p>
      <button
        onClick={() => {
          setCount(count + 1);
        }}
      >
        click
      </button> */}

      <p>{count2}</p>
      <button
        onClick={() => {
          setCount2(count2 + 1);
        }}
      >
        click
      </button>

      <ul>
        <li key="0">0</li>
        <li key="1">1</li>
        {count2 % 2 ? <li key="2">2</li> : null}
        <li key="3">3</li>
        <li key="4">4</li>
      </ul>
    </div>
  );
}

const jsx = (
  <div className="border">
    <h1>全栈</h1>
    <a href="https://www.kaikeba.com/">kkb</a>
    <FunctionComponent name="FunctionComponent" />
    {/* 
    <>
      <h1>omg</h1>
      <h2>omg</h2>
    </> */}
  </div>
);

ReactDOM.render(jsx, document.getElementById("root"));

// console.log("React", React.version); //sy-log

// ! 原生标签
// 文本节点
// 函数组件
// 类组件
// Fragment
