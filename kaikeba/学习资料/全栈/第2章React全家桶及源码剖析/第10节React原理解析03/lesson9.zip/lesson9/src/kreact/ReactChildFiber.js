import { createFiber } from "./createFiber";
import { isArray, isStringOrNumber, Update, Placement } from "./utils";

// returnFiber.deletions = [1,2,3,]
function deleteChild(returnFiber, childToDelete) {
  // // 先删除fiber
  // childToDelete加删除标记
  // 再删除dom节点

  if (returnFiber.deletions) {
    returnFiber.deletions.push(childToDelete);
  } else {
    returnFiber.deletions = [childToDelete];
  }
}

// old 0 1 2 3 4
// new 0 1 3 4
// export function reconcileChildren(returnFiber, children) {
//   if (isStringOrNumber(children)) {
//     return;
//   }
//   const newChildren = isArray(children) ? children : [children];
//   let previosNewFiber = null;
//   let oldFiber = returnFiber.alternate && returnFiber.alternate.child;
//   for (let i = 0; i < newChildren.length; i++) {
//     const newChild = newChildren[i];
//     if (newChild == null) {
//       continue;
//     }
//     const newFiber = createFiber(newChild, returnFiber);
//     const same = sameNode(newFiber, oldFiber);
//     if (same) {
//       Object.assign(newFiber, {
//         alternate: oldFiber,
//         stateNode: oldFiber.stateNode,
//         flags: Update,
//       });
//     }

//     if (!same && oldFiber) {
//       deleteChild(returnFiber, oldFiber);
//     }
//     if (oldFiber) {
//       oldFiber = oldFiber.sibling;
//     }
//     if (previosNewFiber === null) {
//       returnFiber.child = newFiber;
//     } else {
//       previosNewFiber.sibling = newFiber;
//     }

//     previosNewFiber = newFiber;
//   }
// }

// 判断节点是否可以复用
function sameNode(a, b) {
  return !!(a && b && a.key === b.key && a.type === b.type);
}

function placeChild(
  newFiber,
  lastPlacedIndex,
  newIndex,
  shouldTrackSideEffects // 初次渲染（false）还是更新（true）
) {
  newFiber.index = newIndex;
  if (!shouldTrackSideEffects) {
    return lastPlacedIndex;
  }
  const current = newFiber.alternate;

  if (current) {
    const oldIndex = current.index;
    if (oldIndex < lastPlacedIndex) {
      // move
      newFiber.flags = Placement;
      return lastPlacedIndex;
    } else {
      return oldIndex;
    }
  } else {
    newFiber.flags = Placement;
    return lastPlacedIndex;
  }
}

function mapRemainingChildren(currentFirstChild) {
  const existingChildren = new Map();
  let existingChild = currentFirstChild;
  while (existingChild) {
    existingChildren.set(
      existingChild.key || existingChild.index,
      existingChild
    );
    existingChild = existingChild.sibling;
  }
  return existingChildren;
}

// 删除节点链表,头结点是currentFirstChild
function deleteRemainingChildren(returnFiber, currentFirstChild) {
  let childToDelete = currentFirstChild;
  while (childToDelete) {
    deleteChild(returnFiber, childToDelete);
    childToDelete = childToDelete.sibling;
  }
}

export function reconcileChildren(returnFiber, children) {
  if (isStringOrNumber(children)) {
    return;
  }

  const newChildren = isArray(children) ? children : [children];

  //   判断是初次渲染（false）还是更新（true），
  const shouldTrackSideEffects = !!returnFiber.alternate;

  let previosNewFiber = null;
  let oldFiber = returnFiber.alternate && returnFiber.alternate.child;

  //记录上次的插入位置
  let lastPlacedIndex = 0;
  let newIdx = 0;
  //记录oldFiber的下一个节点
  let nextOldFiber = null;
  // 1. 从头遍历新节点，找到第一个不能复用的节点
  for (; oldFiber && newIdx < newChildren.length; newIdx++) {
    const newChild = newChildren[newIdx];
    if (newChild == null) {
      continue;
    }
    if (oldFiber.index > newIdx) {
      nextOldFiber = oldFiber;
      oldFiber = null;
    } else {
      nextOldFiber = oldFiber.sibling;
    }

    const same = sameNode(newChild, oldFiber);

    if (!same) {
      if (oldFiber == null) {
        oldFiber = nextOldFiber;
      }

      break;
    }

    // !newChild, returnFiber 写反了
    const newFiber = createFiber(newChild, returnFiber);
    Object.assign(newFiber, {
      alternate: oldFiber,
      stateNode: oldFiber.stateNode,
      flags: Update,
    });

    lastPlacedIndex = placeChild(
      newFiber,
      lastPlacedIndex,
      newIdx,
      shouldTrackSideEffects
    );

    if (previosNewFiber === null) {
      returnFiber.child = newFiber;
    } else {
      previosNewFiber.sibling = newFiber;
    }
    previosNewFiber = newFiber;
    // !切换
    oldFiber = nextOldFiber;
  }

  // old 1 2 3 4 5 6 7
  // new 0 1 2 3
  if (newIdx === newChildren.length) {
    deleteRemainingChildren(returnFiber, oldFiber);
    return;
  }

  // old 1 2 3 4
  // new 1 2 3 4 5 6 7
  // 初次渲染或者新增节点
  if (oldFiber == null) {
    for (; newIdx < newChildren.length; newIdx++) {
      const newChild = newChildren[newIdx];
      if (newChild == null) {
        continue;
      }

      const newFiber = createFiber(newChild, returnFiber);
      lastPlacedIndex = placeChild(
        newFiber,
        lastPlacedIndex,
        newIdx,
        shouldTrackSideEffects // 初次渲染（false）还是更新（true）
      );

      if (previosNewFiber == null) {
        returnFiber.child = newFiber;
      } else {
        previosNewFiber.sibling = newFiber;
      }

      previosNewFiber = newFiber;
    }

    return;
  }

  // old  2   fiber ->map{key: value}
  // new  5 4 3 8 newChildren[]

  const existingChildren = mapRemainingChildren(oldFiber);
  for (; newIdx < newChildren.length; newIdx++) {
    const newChild = newChildren[newIdx];
    if (newChild == null) {
      continue;
    }
    const newFiber = createFiber(newChild, returnFiber);

    lastPlacedIndex = placeChild(
      newFiber,
      lastPlacedIndex,
      newIdx,
      shouldTrackSideEffects // 初次渲染（false）还是更新（true）
    );

    let matchedFiber = existingChildren.get(newFiber.key || newFiber.index);
    if (matchedFiber) {
      existingChildren.delete(newFiber.key || newFiber.index);
      Object.assign(newFiber, {
        alternate: matchedFiber,
        stateNode: matchedFiber.stateNode,
        flags: Update,
      });
    }

    if (previosNewFiber === null) {
      returnFiber.child = previosNewFiber;
    } else {
      previosNewFiber.sibling = newFiber;
    }
    previosNewFiber = newFiber;
  }
  if (shouldTrackSideEffects) {
    existingChildren.forEach((child) => deleteChild(returnFiber, child));
  }
}
