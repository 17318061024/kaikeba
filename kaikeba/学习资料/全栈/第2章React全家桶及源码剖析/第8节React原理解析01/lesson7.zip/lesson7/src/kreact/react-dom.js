import {scheduleUpdateOnFiber} from "./ReactFiberWorkloop";

// vnode->node
function render(element, container) {
  const FiberRoot = {
    type: container.nodeName.toLocaleLowerCase(),
    props: {children: element},
    stateNode: container,
  };

  //
  scheduleUpdateOnFiber(FiberRoot);
}

export default {render};
