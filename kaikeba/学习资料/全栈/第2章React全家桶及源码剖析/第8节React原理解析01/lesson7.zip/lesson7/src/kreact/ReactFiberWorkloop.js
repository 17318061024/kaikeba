// wip work in progress当前正在工作中的

import {
  updateFragmentComponent,
  updateFunctionComponent,
  updateHostComponent,
} from "./ReactFiberReconciler";
import {isFn, isStr} from "./utils";

let wipRoot = null;
// 下一个fiber节点
let nextUnitOfwork = null;
export function scheduleUpdateOnFiber(fiber) {
  wipRoot = fiber;
  nextUnitOfwork = fiber;
}

function performUnitOfWork(wip) {
  // 1. 更新wip
  const {type} = wip;
  if (isStr(type)) {
    updateHostComponent(wip);
  } else if (isFn(type)) {
    updateFunctionComponent(wip);
  } else {
    updateFragmentComponent(wip);
  }
  // todo
  // 2. 返回下一个要更新的任务 深度优先遍历
  if (wip.child) {
    return wip.child;
  }
  let next = wip;

  while (next) {
    if (next.sibling) {
      return next.sibling;
    }
    next = next.return;
  }
  return null;
}

function workLoop(IdleDeadline) {
  while (nextUnitOfwork && IdleDeadline.timeRemaining() > 0) {
    nextUnitOfwork = performUnitOfWork(nextUnitOfwork);
  }

  if (!nextUnitOfwork && wipRoot) {
    commitRoot();
  }
}

requestIdleCallback(workLoop);

function commitRoot() {
  commitWorker(wipRoot.child);
  wipRoot = null;
}

function commitWorker(wip) {
  if (!wip) return;

  // 1。提交自己
  const {stateNode} = wip;
  // fiber可能没有dom节点，比如函数组件类组件
  let parentNode = getParentNode(wip.return); //wip.return.stateNode; // 父dom节点
  if (stateNode) {
    parentNode.appendChild(stateNode);
  }
  // 2、 子节点
  commitWorker(wip.child);
  // 3.兄弟
  commitWorker(wip.sibling);
}

function getParentNode(fiber) {
  while (fiber) {
    if (fiber.stateNode) {
      return fiber.stateNode;
    }
    fiber = fiber.return;
  }
}
