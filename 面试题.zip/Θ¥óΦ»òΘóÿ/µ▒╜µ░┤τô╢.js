function run(val) {
  let i = Math.floor(val / 2); //换的汽水数
  console.log(i);
}
run(3);
