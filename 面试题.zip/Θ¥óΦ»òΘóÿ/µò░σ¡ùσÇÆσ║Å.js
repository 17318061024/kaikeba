let num = 98766;

function reverse(num) {
  return String(num).split("").reverse().join("");
}
console.log(reverse(num));
