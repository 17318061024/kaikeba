let str = "dffdd";
function res(str) {
  return str.split("").reverse().join("");
}
console.log(res(str));
